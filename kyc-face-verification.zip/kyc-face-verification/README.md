# 📱 KYC Face Verification Android App

এটি একটি **Android Application** প্রজেক্ট, যা KYC (Know Your Customer) এবং মুখ শনাক্তকরণ (Face Verification) প্রক্রিয়ার জন্য তৈরি করা হয়েছে।

---

## 📁 Project Directory Structure

```text
kyc-face-verification/
├── 📄 settings.gradle
├── 📄 build.gradle
├── 📄 app.html
│
├── 📁 app/
│   ├── 📄 build.gradle
│   └── 📁 src/
│       └── 📁 main/
│           ├── 📄 AndroidManifest.xml
│           └── 📁 java/
│               └── 📁 com/example/kycfaceverification/
│                   └── 📄 MainActivity.java
│
└── 📁 .github/
    └── 📁 workflows/
        └── 📄 android.yml
```
