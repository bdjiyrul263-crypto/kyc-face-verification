Face Verify Android Demo (বাংলা)

এটি Android Studio-তে খোলার মতো সোর্স প্রজেক্ট। তৈরি APK এখানে আগে থেকে নেই।

যা আছে:
- WebView-তে KYC Face Verify HTML
- Android camera permission handling
- HTTPS-সদৃশ appassets origin, যাতে browser camera API কাজ করতে পারে
- MediaPipe মডেল/লাইব্রেরি CDN থেকে আনতে ইন্টারনেট দরকার

APK বানাতে:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. এই ফোল্ডার Android Studio-তে Open করুন।
3. Gradle sync শেষ হতে দিন।
4. Build > Build APK(s) নির্বাচন করুন।
5. তৈরি APK ফোনে ইনস্টল করুন এবং Camera permission দিন।

গুরুত্বপূর্ণ:
- এটি ডেমো, আসল KYC/পরিচয় যাচাই পরিষেবা নয়।
- HTML-এ ব্যবহৃত MediaPipe CDN এবং মডেল ডাউনলোডের জন্য ইন্টারনেট লাগবে।
- প্রকাশের আগে নিরাপত্তা, লাইসেন্স, Android SDK/Gradle সামঞ্জস্য এবং বাস্তব ডিভাইসে পরীক্ষা করুন।
